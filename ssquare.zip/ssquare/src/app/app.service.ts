import { Injectable } from "@angular/core";
import { Product } from "./product.model";
import { Subject } from "rxjs";

@Injectable({ providedIn: "root" })
export class AppService {
  private products: Product[] = [];
  private updatedProduct = new Subject();

  getProduct() {
    return [...this.products];
  }
  getUpdateProductListner() {
    return this.updatedProduct.asObservable();
  }

  addProduct(
    productName: string,
    price: number,
    url: string,
    description: string
  ) {
    const product: Product = {
      productName: productName,
      price: price,
      url: url,
      description: description
    };
    this.products.push(product);
    this.updatedProduct.next([...this.products]);
  }
}
