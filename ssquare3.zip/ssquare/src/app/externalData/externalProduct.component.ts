import { Component, OnInit } from "@angular/core";
import { AppService } from './../app.service';



@Component({
  selector: "app-external",
  templateUrl: "./externalProduct.component.html",
  styleUrls: ["./externalProduct.component.css"]
})
export class ExternalProductComponent implements OnInit {

  constructor(public appService:AppService){}
  externalData: any = [];
  ngOnInit() {
    /* this.http.get("../../assets/data.json").
    subscribe((arrayOfProducts =>{

      this.externalData =arrayOfProducts ;
      console.log(this.externalData +"fuwfuwfuwfb")
    }))
  } */
  this.appService.getJson().subscribe((data=>{
    this.externalData = data;
  }))

}
}
