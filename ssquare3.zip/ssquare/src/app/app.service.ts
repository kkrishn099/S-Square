import { Injectable } from "@angular/core";
import { Product } from "./product.model";
import { Subject, Observable } from "rxjs";

import { HttpClient } from '@angular/common/http';






@Injectable({ providedIn: "root" })
export class AppService {
  private products: Product[] = [];
  private updatedProduct = new Subject();
  constructor(public http :HttpClient){}


  getProduct() {
    return [...this.products];
  }
  getUpdateProductListner() {
    return this.updatedProduct.asObservable();
  }
 getJson() :Observable<any> {
   return this.http.get('../assets/data.json')



 }

  addProduct(
    productName: string,
    price: number,
    url: string,
    description: string,
    website:string,
    webUrl :string,
    keyWord:string
  ) {
    const product: Product = {
      productName: productName,
      price: price,
      url: url,
      description: description,
      website :website,
      webUrl :webUrl,
      keyWord :keyWord
    };
    this.products.push(product);
    this.updatedProduct.next([...this.products]);
  }
}
