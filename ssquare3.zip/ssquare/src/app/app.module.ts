import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { AppRouteModule } from "./app-routing.module";
import { RouterModule } from "@angular/router";
import { HttpClientModule } from "@angular/common/http";
import {
  MatToolbarModule,
  MatSelectModule,
  MatButtonModule,
  MatCardModule,
  MatFormFieldModule,
  MatInputModule,
  MatTabsModule,
  MatChipsModule
} from "@angular/material";

import { FormsModule } from "@angular/forms";
import { AddProductComponent } from "./admin/forms/add-product.component";
import { AppComponent } from "./app.component";
import { SearchComponent } from "./search/search.component";
import { HeaderComponent } from "./header/header.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { InventoryComponent } from "./products/inventory.component";
import { ExternalProductComponent } from "./externalData/externalProduct.component";
import { FilterPipe } from "./search/filter.pipe";

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SearchComponent,
    AddProductComponent,
    InventoryComponent,
    ExternalProductComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    AppRouteModule,
    MatToolbarModule,
    BrowserAnimationsModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    FormsModule,
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    MatTabsModule,
    MatChipsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
