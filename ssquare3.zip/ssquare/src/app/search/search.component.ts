import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AppService } from '../app.service';
@Component({
  selector:'app-search',
  templateUrl:'./search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit{

  myArray =[];
  public searchText="";

  constructor(public appService :AppService){}
   
 mySearch(form :NgForm){
   if(form.invalid){
     return
   }
   this.searchText=form.value.search;
   
   console.log(this.searchText);
   
 }
 
 ngOnInit(){
    this.appService.getJson().subscribe((data=>{
      this.myArray =data;
    }))


 }
}
