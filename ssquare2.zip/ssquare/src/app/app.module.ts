import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { AppRouteModule } from "./app-routing.module";
import { RouterModule } from "@angular/router";
import {
  MatToolbarModule,
  MatSelectModule,
  MatButtonModule,
  MatCardModule,
  MatFormFieldModule,
  MatInputModule,
  MatChipsModule
} from "@angular/material";

import { FormsModule } from "@angular/forms";
import { AddProductComponent } from "./admin/forms/add-product.component";
import { AppComponent } from "./app.component";
import { SearchComponent } from "./search/search.component";
import { HeaderComponent } from "./header/header.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { InventoryComponent } from "./products/inventory.component";
import { ExternalDataComponent } from './externalData/externalData.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SearchComponent,
    AddProductComponent,
    InventoryComponent,
    ExternalDataComponent
  ],
  imports: [
    BrowserModule,
    AppRouteModule,
    MatToolbarModule,
    BrowserAnimationsModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatChipsModule,
    FormsModule,
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
