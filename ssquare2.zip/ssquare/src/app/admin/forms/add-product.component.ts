import { Component } from "@angular/core";
import { NgForm } from "@angular/forms";
import { AppService } from "src/app/app.service";

@Component({
  selector: "app-add-product",
  templateUrl: "./add-product.component.html",
  styleUrls: ["./add-product.component.css"]
})
export class AddProductComponent {
  products = [];
  constructor(public appService: AppService) {}
  onAddProduct(form: NgForm) {
    this.appService.addProduct(
      form.value.productName,
      form.value.price,
      form.value.url,
      form.value.description,
      form.value.website
    );
  }
}
