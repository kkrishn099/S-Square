import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';

@Component({
    selector : 'app-external',
    templateUrl: './externalData.component.html',
    styleUrls :['./externalData.component.css']
})
export class ExternalDataComponent implements OnInit{

externalData :[];

 constructor(public appService :AppService){}
    ngOnInit(){
        this.appService.getJson().subscribe((data=>{
            this.externalData = data ;
        }))

    }

    

}