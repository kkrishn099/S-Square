import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
@Component({
  selector:'app-search',
  templateUrl:'./search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent{

  search =[];
   
 mySearch(form :NgForm){
   if(form.invalid){
     return
   }
   console.log(form.value.search)
   
   this.search.push(form.value.search);
   



 }
}
