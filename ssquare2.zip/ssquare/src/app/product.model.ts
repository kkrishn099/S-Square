export interface Product {
  productName: string;
  price: number;
  url: string;
  description: string;
  website :string;
}
