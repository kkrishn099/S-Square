import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { AddProductComponent } from "./admin/forms/add-product.component";
import { SearchComponent } from "./search/search.component";
import { InventoryComponent } from "./products/inventory.component";
import { ExternalDataComponent } from './externalData/externalData.component';
const routes: Routes = [
  { path: "", component: SearchComponent },
  { path: "admin", component: AddProductComponent },
  { path: "inventory", component: InventoryComponent },
  {path :"external" , component:ExternalDataComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

  exports: [RouterModule]
})
export class AppRouteModule {}
